package com.app.aop.joinpoint;

public interface HelloService {
    String sayHello(String name);
    String sayGoodbye(String name);
}
